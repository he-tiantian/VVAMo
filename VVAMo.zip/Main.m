function [cluster_number] = Main(K,Max_Iter,interval,path)


%% Loading graph data
fprintf('Loading data from %s dataset...\n',path);

Pre = 1;

[Y,F,Z,G] = Load_Data(path);

fprintf('Data loaded, now initializing model...\n');

fullrandom = 0;
N = size(Y,1);
Para.Y = Y;
Para.F = F;

Para.Z = Z;
Para.G = G;
Para.V = rand(N,K);

if(fullrandom==1)    
    U = rand(size(F,1),K);
    Para.U = U;
end

Para.K = K;
Para.Max_Iter = Max_Iter;
%Para.alpha = alpha;

Para.interval = interval;
Para.subinterval = 5;
Mini_Gap = 1e-6*interval;
Para.Mini_Gap = Mini_Gap;
%% Model Fitting
if(Pre==1)
    [Result] = Model_Fitting_BMRF_Pre(Para);
else
    [Result] = Model_Fitting_BMRF(Para);
end


fprintf('Model Optimization is done, writing info on latent factors...\n');


%% Output learned latent spaces and log data

if(Pre==1)
    path = strcat('.\',path,'\','Pre','\');
else
    path = strcat('.\',path,'\','MRF','\');
end
mkdir(path);


prefix=strcat('K=',num2str(K));

dlmwrite(strcat(path,prefix,'_V'),Result.V);

dlmwrite(strcat(path,prefix,'_U'),Result.U);

[r,c,v]=find(Result.X);
dlmwrite(strcat(path,prefix,'_X'),[r c v]);

dlmwrite(strcat(path,prefix,'_S'),Result.S);

dlmwrite(strcat(path,prefix,'_H'),Result.H);

if(isfield(Result,'lambda'))
    dlmwrite(strcat(path,prefix,'_lambda'),Result.lambda);
end


fid = fopen(strcat(path,prefix,'.log'), 'w');
fprintf(fid, 'Parameters setting:\n');
fprintf(fid, 'Regularization modeling:\t');

fprintf(fid, 'Gaussian-MRF\n');
fprintf(fid, 'K = %s\tMini_Gap = %s\tMax_Iter = %s\n',num2str(K),num2str(Mini_Gap),num2str(Max_Iter));

fprintf(fid, 'The number of iterations: %s\n', num2str(Result.loop));
fprintf(fid, 'Optimization Time: %s\n', num2str(Result.time));
fprintf(fid, 'Time consumption per iteration: %s\n', num2str(Result.time/Result.loop));
fprintf(fid, 'Objective values:\n');

for i=1:size(Result.Objective,2)
    fprintf(fid, '%s\t', num2str(Result.Objective(1,i)));
end
fclose(fid);

%% Extract network clusters
fprintf('Identifying clusters...\n');

cluster_number = Identify_Cluster_Base(Result.V,path);

fprintf('Job Done!\n');

end

