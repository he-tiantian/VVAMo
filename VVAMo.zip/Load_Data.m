%% Load network data
function [Y,F,Z,G] = Load_Data(path)

path = strcat('.\', path,'\');
info= load(strcat(path, 'statistics'));
n = info(1,1);

edgelist=load(strcat(path,'edgelist'));
edgelist=edgelist+1;
Y = sparse(cat(1,edgelist(:,1),edgelist(:,2)),cat(1,edgelist(:,2),edgelist(:,1)),ones(size(cat(1,edgelist(:,1),edgelist(:,2)),1),1),n,n);


similaritylist=load(strcat(path,'vertex2aid'));
similaritylist(:,1)=similaritylist(:,1)+1;
similaritylist(:,2)=similaritylist(:,2)+1;
m = max(similaritylist(:,2));
F = sparse(similaritylist(:,2),similaritylist(:,1),ones(size(similaritylist,1),1),m, n);

%structural
Z = ComputeCC(Y);
%contextual
%G = ComputeCC(F);

[G]=ComputeFD(F,Y);
Z(Y==0)=0;
G(Y==0)=0;

%dlmwrite(strcat(path,'Z'),full(Z));
%dlmwrite(strcat(path,'G'),full(G));

end

%% Compute contextual and structural correlation between pairwise vertices
function [X] = ComputeCC(F)

di = sum(F,1);
d = sum(sum(F));
FF = F'*F;
X = max(log(bsxfun(@rdivide, d*FF, di'*di)),0);
X=sparse(X);

X(X<log(2))=0;
FF(X==0)=0;
X = sparse(X);
FF = sparse(FF);
X = (-1)*bsxfun(@rdivide,X,log(FF/d));

clear FF;
clear di;
clear d;

end

%% diffusion
function [S] = ComputeFD(F,Y)
% transition matrix
T = bsxfun(@rdivide,Y,sum(Y,1));
T(isnan(T))=0;
alpha = 0.5;
beta = 1;
N = size(Y,1);
%R = diag(beta)*pinv(eye(N)-alpha*T);
R = (beta*eye(N)/(eye(N)-alpha*T));
R(R<0) = 0;


e = 1e-25;
%numView = size(F,2);
%SA = zeros(size(F{1},2),size(F{1},2));
%for i = 1:numView
    FR = F*R;
    S = (FR'*FR);
    sf = sum(FR,1);
    S = S./sqrt(sf'*sf);
    S(isnan(S))=0;
    
    %SF = sum(F{i},1)+e;
    %JF = F{i}'*F{i};
    %S = 0.5*(JF./(SF'*SF));
    %S = S.*(bsxfun(@plus,repmat(SF,size(Y,1),1),SF'));
    S(Y==0) = 0;
    S = sparse(S);
    %S = S./((sum(F{i},1)+e)'*sum(F{i},1)+e);
    %SA = SA + S;
    %SA{i} = S;
	%clear SF; clear JF;
%end
%SA = SA./numView;
%R(Y==0)=0;
%R = sparse(R);

end
