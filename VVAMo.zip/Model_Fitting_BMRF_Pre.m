function [Result] = Model_Fitting_BMRF_Pre(Para)
F = Para.F;
Z = Para.Z;
G = Para.G;
Y = Para.Y;
N = size(Y,1);
K = Para.K;
Max_Iter = Para.Max_Iter;
Mini_Gap = Para.Mini_Gap;

interval = Para.interval;
subinterval = Para.subinterval;

lambda = ones(N,1);

if(isfield(Para,'V'))
    V = Para.V;
else
    V = rand(N,K);
end

count = 1;

% Generating U
if(isfield(Para,'U'))
    U = Para.U;    
else
    VV = V'*V;
    FV = F*V;
    U = max(FV/VV,0);
    U = bsxfun(@rdivide, U,sum(U,1));
    clear FV; 
    clear VV;
end

if(isfield(Para,'S'))
    S = Para.S;
else
    S = rand(N,2);
    S = bsxfun(@rdivide, S,sum(S,2));
end

if(isfield(Para,'S'))
    H = Para.H;
else
    H = rand(N,K);
    %H = bsxfun(@rdivide, H,sum(H,1));
end


if(isfield(Para,'X'))
    X = Para.X;
else
    X = rand(N,N);
    X((Z+G)==0)=0;
    X = bsxfun(@rdivide, X,max(sum(X,2),1e-10));
    %X = full(X);
end

clear Para;
SZSG_temp = bsxfun(@plus,bsxfun(@times,bsxfun(@times,Z,S(:,1)),S(:,1)'),bsxfun(@times,bsxfun(@times,G,S(:,2)),S(:,2)'));

%learning optimal vertex allocation before network clustering
fprintf('Learning X and S...\n');
for loop = 1:50
    [X] = update_X_MRF(X,SZSG_temp);
    [S,SZSG_temp] = update_S(S,X,SZSG_temp,Z,G);
end

%for loop=1:20
%    [V,~] = update_V(V,U,X,H,Y,F,lambda);
%    [lambda] = update_lambda(V,lambda);
%    [H] = update_H(H,X,V);
%    [U] = update_U(U,V,F);
%end

fprintf('Model Optimization begins...\n');

Objective(count) = Compute_Obj(Y,F,V,U,X,H,lambda);
fprintf('The value of objective function after initialization is %f.\n', Objective(count));
tic;
for loop = 1:Max_Iter
    
    %update V
    [V,~] = update_V(V,U,X,H,Y,F,lambda);
    
    %update lambda
    %if(loop==1||mod(loop,subinterval)==0)
        [lambda] = update_lambda(V,lambda);
    %end
    
    %update S
    %if(loop==1||mod(loop,subinterval)==0)
    %    if(loop<=50)
    %        [S,SZSG_temp] = update_S(S,X,SZSG_temp,Z,G);
    %    end
    %end
    
    %update X
    %[X] = update_X(V,X,H,XH,SZSG_temp);
    
    %update H
    [H] = update_H(H,X,V);
    
    %update U
    [U] = update_U(U,V,F);
    
    %if(loop==1)
    %   count = count + 1;
    %   Objective(count) = Compute_Obj(Y,F,V,U,X,H,lambda);
    %   fprintf('The value of objective function after iteration %d is %f.\n', loop, Objective(count));
    %end
    
    if(mod(loop,interval)==0&&loop~=Max_Iter&&loop>1)
       count = count + 1;
       Objective(count) = Compute_Obj(Y,F,V,U,X,H,lambda);
       if(abs(Objective(1,count)-Objective(1,count-1))<Mini_Gap)
           fprintf('The improvement of objective value after iteration %d is less than Minimum Gap %f, the algorithm is terminated.\n', loop, Mini_Gap);
           Objective = Objective(1,1:count);
           break;
       else
           fprintf('The value of objective function after iteration %d is %f.\n', loop, Objective(count));
       end
    end
    if(loop==Max_Iter)
        count = count + 1;
        %Objective(count) = Compute_Obj(Y,F,V,B,U);
        Objective(count) = Compute_Obj(Y,F,V,U,X,H,lambda);
        fprintf('The value of objective function after %d iteration is %f.\n', Max_Iter, Objective(count));
    end
       
    
end
time = toc;

Result.V = V;
Result.U = U;
Result.X = X;
Result.S = S;
Result.H = H;
Result.lambda = lambda;

Result.time = time;
Result.loop = loop;
Result.Objective = Objective;

end

function [V,XH] = update_V(V,U,X,H,Y,F,lambda)

% derivative of log p(Y|V,P)
VV = V*V';
YVV = Save_Divide(Y,VV);
YVVV = 2*YVV*V;

SV = 2*sum(V,1);

% derivative of log p(F|V,U)
UV = U*V';
FUV = Save_Divide(F,UV);
FUVU = FUV'*U;

% derivative of manifold regularization
XH = X*H;
XHV = XH.*V;
expXHV = exp(XHV);
SexpXHV = sum(sum(expXHV));
XHexpXHV = XH.*expXHV;
XHexpXHV = XHexpXHV./SexpXHV;

Nu = YVVV+FUVU+XH;

De = bsxfun(@plus,bsxfun(@times,V,lambda+1)+XHexpXHV,SV);

V = V.*((Nu)./max(De,realmin));

end

function [U] = update_U(U,V,F)
e = 1e-25;

UV = U*V';
FUV = Save_Divide(F,UV);
FUVV = FUV*V;
UFUVV = U.*FUVV;

U = bsxfun(@rdivide,UFUVV,max(sum(UFUVV,1),e));

end

function [X] = update_X_MRF(X,SGSZ)
%update X only considering MRF of vertex allocation

XSGSZ = bsxfun(@times,X,SGSZ);
expXSGSZ = exp(XSGSZ);
AexpXSGSZ = sum(sum(expXSGSZ));

SGSZexpXSGSZ = bsxfun(@times,SGSZ,expXSGSZ);
SGSZexpXSGSZ = SGSZexpXSGSZ./AexpXSGSZ;

X = X.*((SGSZ)./(max(X+SGSZexpXSGSZ,realmin)));

X = bsxfun(@rdivide,X,max(sum(X,2),1e-25));

end




function [X] = update_X(V,X,H,XH,SGSZ)

XHV = XH.*V;
expXHV = exp(XHV);
SexpXHV = sum(sum(expXHV));
expXHV = expXHV./SexpXHV;

expXHVV = expXHV.*V;
expXHVVH = expXHVV*H';
%expXHVVH = expXHVVH./SexpXHV;

VH = V*H';

XSGSZ = bsxfun(@times,X,SGSZ);
expXSGSZ = exp(XSGSZ);
AexpXSGSZ = sum(sum(expXSGSZ));

SGSZexpXSGSZ = bsxfun(@times,SGSZ,expXSGSZ);
SGSZexpXSGSZ = SGSZexpXSGSZ./AexpXSGSZ;

X = X.*((SGSZ + VH)./(max(expXHVVH+X+SGSZexpXSGSZ,realmin)));

X = bsxfun(@rdivide,X,max(sum(X,2),1e-25));

end

function [H] = update_H(H,X,V)
XH = X*H;

XHV = XH.*V;
expXHV = exp(XHV);
SexpXHV = sum(sum(expXHV));
expXHV = expXHV./SexpXHV;
expXHVV = expXHV.*V;

XexpXHVV=X'*expXHVV;

XV = X'*V;

H = H.*(XV./max(XexpXHVV+H,realmin));
%H = bsxfun(@rdivide, H,max(sum(H,1),1e-25));

end

function [S,SZSG_temp] = update_S(S,X,SZSG_temp,Z,G)

expXSGSZ = bsxfun(@times,X,SZSG_temp);
expXSGSZ = exp(expXSGSZ);
AexpXSGSZ = sum(sum(expXSGSZ));

ZX = bsxfun(@times,Z,X);
GX = bsxfun(@times,G,X);
SZXexpXSGSZ = ((ZX.*expXSGSZ)*S(:,1))./AexpXSGSZ;
SZX = ZX*S(:,1);

SGXexpXSGSZ = ((GX.*expXSGSZ)*S(:,2))./AexpXSGSZ;
SGX = GX*S(:,2);

S(:,1) = S(:,1).*(SZX./max(SZXexpXSGSZ,1e-25));
S(:,2) = S(:,2).*(SGX./max(SGXexpXSGSZ,1e-25));
S = bsxfun(@rdivide,S, max(sum(S,2),1e-25));

SZSG_temp = bsxfun(@plus,bsxfun(@times,bsxfun(@times,Z,S(:,1)),S(:,1)'),bsxfun(@times,bsxfun(@times,G,S(:,2)),S(:,2)'));
end

function [lambda] = update_lambda(V,lambda)
K = size(V,2);

lambda = K./(max(sum(V.^2,2)+lambda,realmin));

end


function [Obj] = Compute_Obj(Y,F,V,U,X,H,lambda)
Obj = 0;

VV = V*V';
LVV = Logrithm(VV);
Obj = Obj + sum(sum(Y.*LVV));
Obj = Obj - sum(sum(VV));

%P(F|V,U)
UV = U*V';
LUV = Logrithm(UV);
Obj = Obj + sum(sum(F.*LUV));

XH = X*H;
XHV = XH.*V;
expXHV = exp(XHV);
Obj = Obj + sum(sum(XHV));
Obj = Obj - log(sum(sum(expXHV)));

%DelX = bsxfun(@times,X,SZSG);
%Obj = Obj + (sum(sum(DelX)));
%Obj = Obj -log(sum(sum(exp(DelX))));

K = size(V,2);
Obj = Obj + 0.5*K*sum(log(lambda));
Obj = Obj - 0.5*sum(sum(bsxfun(@times,V.^2,lambda+1)));

end

function [L] = Logrithm(A)
A(A==0) = 1;
L = log(A);
end


function [Q] = Save_Divide(Nu, De)
Q = Nu./De;
Q(De==0)=0;
end
