function [cluster_number] = Identify_Cluster_Base(G,path,tau)
%   This function is used to identify Clusters after the matrix of
%   cluster affiliation is obtained.
%   Input: 
%   G, the matrix of weights representing the affliation of
%   clusters(Nv*K); 
%   A: adjacency matrix of network graph; 
%   phi: Gij is set to zero if Gij is lower than phi; 
%   tau: threshold that is used to control the overlapping rate;
%   path: directory to store the cluster file.
%
%   Output: 
%   cluster_number: The number of Clusters in G.

% check parameter setting
if((nargin~=2)&&(nargin~=3))
    fprintf('Wrong setting of args!\n');
    return;
end
   % G and path is set
if(nargin==2)
    [~,K] = size(G);
	G = G./repmat(max(G,[],2),1,K);
	G(isnan(G))=0;
	G(G<1)=0;
    G(G>0)=1;
    cluster_number = outputcluster(G,K,path);
end

   % G, A, mini_size and path is set
if (nargin==3&&tau>0)
    [~,K] = size(G);
	%tau = tau./K;
    G(G<tau)=0;
    G(G>0)=1;
    cluster_number = outputcluster(G,K,path);
end

end


function [cluster_number] = outputcluster(C,K,path)

a = strsplit(path,'\');
path0 = strcat(a{1},'\',a{2},'\');

%Cluster Position: where the latent features locate in the latent spaces

if(exist(strcat(path0,'proteins'),'file')==0)
    %no file for vertex name, id as vertex name
    fid = fopen(strcat(path,'K=',num2str(K),'.Cluster'), 'w');
    count = 0;
    for k=1:K    
        index_k = find(C(:,k));
        if(~isempty(index_k))
            count = count + 1;
            fprintf(fid, '%s\n', strcat('Cluster #',num2str(count),'  Position: ', num2str(k)));
            for i= 1:length(index_k)
                fprintf(fid, '%s\t',num2str(index_k(i)-1));
            end 
            fprintf(fid, '\n');
        end
    end
    fclose(fid);
    cluster_number = count;
else
    %vertex name
    P = load(strcat(path0,'proteins'));
    fid = fopen(strcat(path,'K=',num2str(K),'.Cluster'), 'w');
    count = 0;
    for k=1:K
        index_k = find(C(:,k));
        if(~isempty(index_k))
            count = count + 1;
            fprintf(fid, '%s\n', strcat('Cluster #',num2str(count),'  Position: ', num2str(k)));
            for i= 1:length(index_k)
                fprintf(fid, '%s\t',num2str(P(index_k(i),1)));
            end
            fprintf(fid, '\n');
        end 
    end
    fclose(fid);
    cluster_number = count;
end

end




